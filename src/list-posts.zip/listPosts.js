module.exports.handler = async (ev) => {
  console.log('Event: ', ev)

  return [
        {id: "12345",title: "Test Title 1", content: "dskflsfjskldfjsldkfs"}
      ]
}
